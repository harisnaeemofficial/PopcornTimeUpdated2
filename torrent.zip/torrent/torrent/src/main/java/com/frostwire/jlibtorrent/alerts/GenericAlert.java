package com.frostwire.jlibtorrent.alerts;

import com.frostwire.jlibtorrent.swig.alert;

/**
 * @author gubatron
 * @author aldenml
 */
public final class GenericAlert extends AbstractAlert<alert> {

    public GenericAlert(alert alert) {
        super(alert);
    }
}

package com.android.torrent;

public enum TorrentPriority {
    NOT_DOWNLOAD,
    NORMAL,
    HIGH
}